import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { addUnit } from '../../lib/mockData'; // ← use local function

const AddUnit = () => {
  const router = useRouter();
  const { propertyId } = useLocalSearchParams();

  const [unitName, setUnitName] = useState('');
  const [floor, setFloor] = useState('');
  const [rooms, setRooms] = useState('');
  const [bathrooms, setBathrooms] = useState('');
  const [size, setSize] = useState('');

  const handleSubmit = async () => {
    if (!unitName || !propertyId) {
      Alert.alert("Missing required fields");
      return;
    }

    const result = await addUnit({
      unitName,
      floor,
      rooms,
      bathrooms,
      size,
      propertyId,
    });

    console.log("New unit:", result);
    Alert.alert("Success", "Unit added successfully");
    router.back();
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>Add Unit</Text>
        <TouchableOpacity style={styles.closeButton} onPress={() => router.back()}>
          <Ionicons name="close" size={24} color="white" />
        </TouchableOpacity>
      </View>

      <View style={styles.form}>
        <TextInput
          placeholder="Unit Name (e.g. Apt 102)"
          value={unitName}
          onChangeText={setUnitName}
          style={styles.input}
        />
        <TextInput
          placeholder="Floor"
          value={floor}
          onChangeText={setFloor}
          keyboardType="numeric"
          style={styles.input}
        />
        <TextInput
          placeholder="Number of Rooms"
          value={rooms}
          onChangeText={setRooms}
          keyboardType="numeric"
          style={styles.input}
        />
        <TextInput
          placeholder="Number of Bathrooms"
          value={bathrooms}
          onChangeText={setBathrooms}
          keyboardType="numeric"
          style={styles.input}
        />
        <TextInput
          placeholder="Size (m²)"
          value={size}
          onChangeText={setSize}
          keyboardType="numeric"
          style={styles.input}
        />

        <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
          <Text style={styles.submitButtonText}>Add</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { backgroundColor: '#F5F7FA', flex: 1 },
  header: {
    backgroundColor: '#17b8a6',
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 15,
    alignItems: 'center',
    elevation: 4,
  },
  headerText: { color: 'white', fontSize: 18, fontWeight: 'bold' },
  closeButton: { padding: 5 },
  form: { padding: 20 },
  input: {
    backgroundColor: 'white',
    padding: 15,
    marginVertical: 8,
    borderRadius: 10,
    borderColor: '#ccc',
    borderWidth: 1,
  },
  submitButton: {
    backgroundColor: '#17b8a6',
    padding: 15,
    borderRadius: 10,
    marginTop: 20,
    alignItems: 'center',
  },
  submitButtonText: { color: 'white', fontWeight: 'bold', fontSize: 16 },
});

export default AddUnit;
