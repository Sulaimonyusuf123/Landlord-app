
import { Stack } from 'expo-router';
import React from 'react';

export default function AppLayout() {
  return (
    <Stack
      screenOptions={{
        headerShown: false, // Hide header globally
      }}
    >
      <Stack.Screen name="dashboard" />
      <Stack.Screen name="addProperty" />
      <Stack.Screen name="addTenant" />
      <Stack.Screen name="bills" />
      <Stack.Screen name="tenants" />
      <Stack.Screen name="notification" />
      <Stack.Screen name="navbar" />
      <Stack.Screen name="units" /> {/* ✅ added this line */}
    </Stack>
  );
}
